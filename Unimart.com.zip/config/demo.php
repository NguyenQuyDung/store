<?php
return [
    'table_module' => [
        'Admin',
        'Category',
        'Slider',
        'Product',
        'Setting',
        'User',
        'Menu',
        'Post',
        'Role',
        
    ],
    'module_children1' => [
        'List',
        'Add',
        'Edit',
        'Action',
        'Delete',
        'Permissons'
    ]
];
