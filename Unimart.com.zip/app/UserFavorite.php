<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserFavorite extends Model
{
   // protected $guarded=[];
    protected $table = 'user_favorite';
}
